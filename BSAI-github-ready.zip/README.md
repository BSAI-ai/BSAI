# BSAI

BSAI is a modern, mobile-friendly AI tools website built with HTML, CSS, and JavaScript.

The homepage introduces a clean productivity suite with tools for AI-assisted writing, job applications, communication, and summarization.

## Features

- AI Chat
- Resume Builder
- Cover Letter Generator
- Email Writer
- Text Summarizer
- Multilingual language selector
- Browser language auto-detection
- Responsive layout for desktop, tablet, and mobile
- Translation-ready JavaScript dictionary for future AI translation features

## Supported Languages

- English
- Japanese
- Nepali
- Hindi
- German
- French
- Spanish
- Chinese

## Project Structure

```text
.
|-- index.html
|-- styles.css
|-- script.js
|-- README.md
`-- outputs/
    |-- index.html
    |-- styles.css
    `-- script.js
```

The root files are ready for GitHub Pages deployment. The `outputs/` folder contains the same user-facing deliverable files created during development.

## Run Locally

Open `index.html` in a browser.

No build step or package installation is required.

## Deploy To GitHub Pages

1. Create a new repository on GitHub.
2. Push this project to the repository.
3. In GitHub, open **Settings > Pages**.
4. Set **Source** to `Deploy from a branch`.
5. Choose the `main` branch and the `/root` folder.
6. Save the settings.

GitHub Pages will publish the site from `index.html`.

## Git Commands

If Git is installed, run:

```bash
git init
git add .
git commit -m "Initial BSAI homepage"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace `YOUR-USERNAME` and `YOUR-REPOSITORY` with your GitHub account and repository name.

## License

This project is ready for a license file if you want to make it open source.
